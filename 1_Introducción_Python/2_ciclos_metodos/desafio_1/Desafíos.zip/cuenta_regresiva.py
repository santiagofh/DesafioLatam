#%%
cuenta_regresiva=int(input("Ingrese un numero para la cuenta\n"))
i=cuenta_regresiva
while i > 0:
    print("Iteración {}".format(i))
    i-=1
