#%%
for i in range(0,50):
    print("Iteracion {}".format(i+1))