# %%
z=""
var=int(input("Ingrese numero:\n"))
for i in range(1,var+1):
    x=str(i)
    z=z+x
    print(z)
# %%
