# %%
var=int(input("ingrese un numero\n"))
i=1
x=0
while i <= var:
    if i%2==0:
        x+=i
    i+=1
print(x)
# %%
