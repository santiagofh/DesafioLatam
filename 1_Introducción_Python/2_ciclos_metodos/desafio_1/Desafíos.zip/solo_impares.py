# %%
var=int(input("ingrese un numero:\n"))
i=1
while i <= var:
    if i%2==0:
        print(i-1)
    i+=1
# %%
