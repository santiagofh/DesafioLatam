import sys

n1 = int(sys.argv[1])
n2 = int(sys.argv[2])
n3 = int(sys.argv[3])

if n1 > n2 and n1 > n3:
    print("el mayor es "+str(n1))
elif n2 > n1 and n2 > n3:
    print("el mayor es "+str(n2))
elif n3 > n1 and n3 > n2:
    print("el mayor es "+str(n3))
else:
    print("hay numeros iguales")